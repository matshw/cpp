#ifndef ELETRODOMESTICO_H
#define ELETRODOMESTICO_H
#include <iostream>
#include <string>

using namespace std;


class Eletrodomestico
{
    public:
        Eletrodomestico();
        Eletrodomestico(bool ligadoE);
        void ligar();
        void desligar();
        void imprimir();

    private:
        bool ligado;
};

#endif // ELETRODOMESTICO_H
