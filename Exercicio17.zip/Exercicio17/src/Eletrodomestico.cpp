#include "Eletrodomestico.h"
#include <iostream>
#include <string>

using namespace std;

Eletrodomestico::Eletrodomestico()
{
}

Eletrodomestico::Eletrodomestico(bool ligadoE)
{
    ligado=ligadoE;
}

void Eletrodomestico::imprimir()
{
    if(ligado == true)
        cout<<"O eletrodomestico esta ligado.";
    else
        cout<<"O eletrodomestico esta desligado.";
}

void Eletrodomestico::ligar()
{
    ligado=true;
}

void Eletrodomestico::desligar()
{
    ligado=false;
}
