#include <iostream>
#include <string>
#include "Eletrodomestico.h"

using namespace std;

int main()
{
    int aux,sair;
    aux=0;
    sair=0;

    Eletrodomestico eletr();
    Eletrodomestico eletro(0,1,200,100);

    do {
    cout<<"\nDigite 1 para ligar o eletrodomestico, 0 para desligar, \n2 para mostrar o estado e 9 para sair da operacao: ";
    cin>>aux;

        if(aux == 1) {
            eletro.ligar();
            eletro.imprimir();
        }
        if(aux == 0) {
            eletro.desligar();
            eletro.imprimir();
        }
        if(aux == 2) {
            eletro.imprimir();
        }
        if(aux == 9)
            sair=9;
    }while(sair!=9);

    Eletrodomestico eletro2(true);
    eletro2.imprimir();
}
